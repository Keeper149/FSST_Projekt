"""
simple sample file illustration the use of ORM declarative classes within SQLAlchemy
Sets up a simple datebase for study & test-purposes
"""
#imports for declarative mapping
from sqlalchemy.orm import Session
from typing import List
from typing import Optional
from sqlalchemy.orm import Mapped
from sqlalchemy.orm import mapped_column
from sqlalchemy.orm import relationship
from sqlalchemy import create_engine
from sqlalchemy import String
from sqlalchemy import ForeignKey
#class mapping using decorators
from sqlalchemy.orm import registry
#mapping textual sql to orm objects
#classes instantiated as Python dataclass objects (i.e. autocreation of __init___, __rep__ etc.)
#==> can't use autoincrement pk feature of orm 

from sqlalchemy.engine import Engine
from sqlalchemy import event

@event.listens_for(Engine, "connect")
def set_sqlite_pragma(dbapi_connection, connection_record):
    """Enable fk check on each connection"""
    cursor = dbapi_connection.cursor()
    cursor.execute("PRAGMA foreign_keys=ON")
    cursor.close()

#create registry required for managing orm objects and dbs
mapper_reg = registry()

#apply decorator to each class definition
#NOTE: decorators are NOT inherited -> add to ALL classes
@mapper_reg.mapped
class User:
    #tablename
    __tablename__ = "user_account"
    #pk column in int format
    id: Mapped[int] = mapped_column(primary_key=True)
    #string/varchar column limited to 30 chars
    name: Mapped[str] = mapped_column(String(30))
    #nullable column in string format
    fullname: Mapped[Optional[str]]
    #NOTE: addresses attribute represents a list of Address instances
    #NOTE: save-update cascade on Address Objects -> changes propagated to Address object
    addresses: Mapped[List["Address"]] = relationship(back_populates="user",    
        cascade="all, delete, delete-orphan", passive_deletes=True, passive_updates=True)

    #optional method, analogue to __str__ giving a string representation of the object
    def __repr__(self) -> str:
        return f"User(id={self.id!r}, name={self.name!r}, fullname={self.fullname!r})"

#add mapping decorator
#class for address table
@mapper_reg.mapped
class Address:
    #tablename
    __tablename__ = "address"
    #pk column in int format
    id: Mapped[int] = mapped_column(primary_key=True)
    #string/varchar column
    email_address: Mapped[str]
    #establish fk constraint with column id in table user_account
    #delete and update options propagated to Address class
    user_id: Mapped[int] = mapped_column(ForeignKey("user_account.id", ondelete="CASCADE", onupdate="CASCADE"))
    cock_id:Mapped[int] = mapped_column(ForeignKey("cockid", ondelete="CASCADE", onupdate="CASCADE"))
    #NOTE: user attribute ist mapped to User class
    #NOTE: save-update cascade on User.addresses attribute -> i.e., changes propagated to User object
    user: Mapped["User"] = relationship(back_populates="addresses")

    #optional method, analogue to __str__ giving a string representation of the object
    def __repr__(self) -> str:
        return f"Address(id={self.id!r}, email_address={self.email_address!r}, user_id={self.user_id!r})"
    

#create database connection engine
#create db in memory -> useful for testing 
#NOTE: not advisable in production setting;-)
#engine = create_engine("sqlite+pysqlite:///:memory:", echo=True)
#TODO: add the path of your db-folder here and activate line befor start
engine = create_engine(r"sqlite+pysqlite:///C:\Users\Max\Documents\Schule\4CHEL\FSST\Spotify_Website_Projekt\ORM\my_db.db", echo=True)
#commit orm ddl to db using metadata object from Base class
mapper_reg.metadata.create_all(engine)


#insert ORM-Objects into db using ORM-session
#create objects using the implicitly generated __init__-constructor and named attributes
#Primary Key value id left to None (to be incremented by auto-increment feature of db)
#object state: transisient (not associated with db yet)
squidward = User(name="squidward", fullname="Squidward Tentacles")
krabs = User(name="Sehkrabs", fullname="Eugene H. Krabs")

#open session and close it automatically
#analogue to with-syntax for file reading
with Session(engine) as session:
    #add objects to session
    #object state: pending
    session.add(squidward)
    session.add(krabs)

    #create address object
    krabs.addresses.append(Address(email_address="Fiend@hallo.com"))
    krabs.addresses.append(Address(email_address="hallo@testcrab.com"))
    
    #commit objects to db (calls autoflush-feature on session object)
    session.commit()